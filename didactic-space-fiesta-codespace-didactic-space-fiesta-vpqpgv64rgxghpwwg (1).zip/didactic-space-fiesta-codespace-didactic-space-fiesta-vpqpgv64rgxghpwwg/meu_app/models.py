from django.db import models

# Create your models here.
class Equipamento(models.Model):
    nome = models.CharField(max_length=150)
    numero_patrimonio = models.DecimalField(max_digits=10, decimal_places=0)
    tipo = models.CharField(default=0)
    em_uso = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.nome} {self.numero_patrimonio} {self.tipo} {self.em_uso}"