
from django.shortcuts import render, redirect, get_object_or_404
from .models import Equipamento
from .forms import EquipamentoForm

# 1. Tela de Listagem / Dashboard
def dashboard_equipamentos(request):
    equipamentos = Equipamento.objects.all()
    return render(request, 'meu_app/dashboard.html', {'equipamentos': equipamentos})

# 2. Tela de Cadastro com Validação e Redirecionamento
def cadastrar_equipamento(request):
    if request.method == 'POST':
        form = EquipamentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dashboard_equipamentos')
    else:
        form = EquipamentoForm()
    return render(request, 'meu_app/cadastrar_produto.html', {'form': form})

# 3. Tela de Detalhes Dinâmica
def detalhe_equipamento(request, id):
    equipamento = get_object_or_404(Equipamento, id=id)
    return render(request, 'meu_app/detalhe_produto.html', {'equipamento': equipamento})
